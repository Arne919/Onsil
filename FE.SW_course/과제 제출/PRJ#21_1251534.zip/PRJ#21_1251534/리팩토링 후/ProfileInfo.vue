<template>
  <div class="profile-info">
    <div class="follow-button-wrapper">
      <div class="profile-header">
        <img :src="`http://127.0.0.1:8000${user.profile_picture}`" class="profile-img" alt="프로필 사진" />
        <div class="profile-basic">
          <h1 class="profile-title">{{ user.username }}</h1>
          <div class="profile-follow-stats">
            <p>팔로잉 {{ user.followingsCount }}</p>
            <hr />
            <p>팔로워 {{ user.followersCount }}</p>
          </div>
        </div>
      </div>
      <button v-if="!isOwnProfile" class="follow-button" @click="toggleFollow">
        {{ isFollowed ? '언팔로우' : '팔로우' }}
      </button>
    </div>

    <div class="profile-details">
      <div class="stats-row">
        <div class="stat-box">
          <img :src="getRankImage(user.rank_title)" alt="랭크 이미지" class="rank-icon-small" />
          <p class="stat-num">{{ user.points }}</p>
        </div>
        <div class="stat-box">
          <h1>📝</h1>
          <p class="stat-num-count">{{ user.articlesCount }}</p>
        </div>
        <div class="stat-box">
          <h1>❤️</h1>
          <p class="stat-num">{{ user.likesCount }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed } from 'vue';

const props = defineProps({
  user: Object,
  isFollowed: Boolean,
  isOwnProfile: Boolean,
});

const emit = defineEmits(['toggle-follow']);

const toggleFollow = () => {
  emit('toggle-follow');
};

const getRankImage = (rankTitle) => {
  const rankImages = {
    Bronze: '@/assets/BronzeRank.png',
    Silver: '@/assets/SilverRank.png',
    Gold: '@/assets/GoldRank.png',
    Platinum: '@/assets/PlatinumRank.png',
    Diamond: '@/assets/DiamondRank.png',
  };
  return rankImages[rankTitle] || rankImages.Bronze;
};
</script>

<style scoped>
/* 스타일은 기존 코드에서 복사 */
</style>
