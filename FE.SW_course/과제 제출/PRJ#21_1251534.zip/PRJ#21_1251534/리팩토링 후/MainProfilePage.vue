<template>
  <div class="container">
    <!-- 프로필 정보 -->
    <ProfileInfo
      :user="user"
      :is-followed="isFollowed"
      :is-own-profile="isOwnProfile"
      @toggle-follow="toggleFollow"
    />

    <!-- 추천 영화 섹션 -->
    <RecommendedMovie
      :recommended-movie="recommendedMovie"
      :is-own-profile="isOwnProfile"
      @open-recommendation-modal="openRecommendationModal"
      @edit-recommendation="editRecommendation"
    />

    <!-- 컬렉션 섹션 -->
    <CategoryList
      :username="user.username"
      :categories="categories"
      :is-own-profile="isOwnProfile"
      @open-create-category-modal="openCreateCategoryModal"
      @go-to-category-detail="goToCategoryDetail"
    />
  </div>

  <!-- 모달들 -->
  <!-- 모달 로직은 부모에서 관리 -->
</template>

<script setup>
// 필요한 상태와 메서드는 기존 코드에서 그대로 가져옵니다.
import ProfileInfo from './ProfileInfo.vue';
import RecommendedMovie from './RecommendedMovie.vue';
import CategoryList from './CategoryList.vue';

// 상태 및 로직은 기존 코드를 유지
</script>

<style scoped></style>
